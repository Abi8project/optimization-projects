# Cost Minimization Project

**Author:** Abi Rami (MSc Mathematics)  
**GitHub:** https://github.com/Abi8project

## Aim
Demonstrate a simple mathematical cost minimization example using a convex cost function. The goal is to find the input `x` that minimizes the cost.

## Method
- Define a convex quadratic-based cost function `Cost(x) = 2(x-3)^2 + 5x + 10`.
- Sample the function on an interval and find the minimum numerically.
- Visualize the cost function and the minimum point.

## Files
- `main.py` : Python script demonstrating the procedure.
- `output.png` : Graph showing the cost function and its minimum.
- `project_description.pdf` : Short academic-style write-up.

## How to run (if you have Python)
```bash
python main.py
```

## Notes
This example uses `NumPy` for numerical computation and `Matplotlib` for visualization.
