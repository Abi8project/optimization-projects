# Simple Cost Minimization Example
# Author: Abi Rami (MSc Mathematics)
# GitHub: https://github.com/Abi8project

import numpy as np
import matplotlib.pyplot as plt

def cost(x):
    # Example convex cost function: quadratic + linear term
    return 2*(x-3)**2 + 5*x + 10

# search for minimum on interval
x = np.linspace(-5, 10, 500)
y = cost(x)
xmin = x[np.argmin(y)]
ymin = y.min()

print("Minimum cost at x =", xmin, "with cost =", ymin)

# Save figure
plt.figure(figsize=(6,4))
plt.plot(x, y, label='Cost(x)')
plt.scatter([xmin], [ymin], color='red', zorder=5)
plt.annotate(f"min at x={xmin:.2f}", xy=(xmin, ymin), xytext=(xmin+1, ymin+20),
             arrowprops=dict(arrowstyle='->'))
plt.title("Cost Minimization Example")
plt.xlabel("x")
plt.ylabel("Cost")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("output.png")
plt.close()
