# Data Analysis Optimization Project

**Author:** Abi Rami (MSc Mathematics)  
**GitHub:** https://github.com/Abi8project

## Aim
Demonstrate a simple data-analysis optimization using least-squares linear regression to find the best-fit line for a dataset.

## Method
- Create a sample dataset.
- Use least-squares (NumPy linear algebra) to compute slope and intercept.
- Visualize the data points and best-fit line.

## Files
- `main.py` : Python script demonstrating the procedure.
- `output.png` : Graph showing data points and the best-fit line.
- `project_description.pdf` : Short academic-style write-up.

## How to run (if you have Python)
```bash
python main.py
```

## Notes
This example uses `Pandas` to store tabular data, `NumPy` for numerical computation, and `Matplotlib` for visualization.
