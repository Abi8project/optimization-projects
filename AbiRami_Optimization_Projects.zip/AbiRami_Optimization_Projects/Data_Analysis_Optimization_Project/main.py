# Data Analysis Optimization - Best Fit Line Example
# Author: Abi Rami (MSc Mathematics)
# GitHub: https://github.com/Abi8project

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Sample dataset (x, y)
data = pd.DataFrame({'x': [1,2,3,4,5,6,7,8,9,10],
                     'y': [2.1,2.9,3.7,4.1,5.0,6.2,6.8,7.9,9.1,9.8]})

# Compute linear fit (least squares)
x = data['x'].values
y = data['y'].values
A = np.vstack([x, np.ones(len(x))]).T
m, c = np.linalg.lstsq(A, y, rcond=None)[0]
print("Best fit line: y = {:.4f}x + {:.4f}".format(m, c))

# Plot data and best-fit line
plt.figure(figsize=(6,4))
plt.scatter(x, y, label='Data points')
plt.plot(x, m*x + c, label=f'Fit: y={m:.2f}x+{c:.2f}')
plt.title("Data Analysis Optimization - Best Fit Line")
plt.xlabel("x")
plt.ylabel("y")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.savefig("output.png")
plt.close()
