# GitHub Upload Guide

See the PDF `how_to_upload.pdf` for step-by-step instructions.